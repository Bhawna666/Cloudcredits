const passwordInput = document.getElementById('password');
const strengthBar = document.getElementById('strength-bar');
const strengthText = document.getElementById('strength-text');

passwordInput.addEventListener('input', () => {
    const password = passwordInput.value;
    let strength = 0;

    if (password.length >= 6) strength++;
    if (password.match(/[A-Z]/)) strength++;
    if (password.match(/[0-9]/)) strength++;
    if (password.match(/[^a-zA-Z0-9]/)) strength++;

    switch (strength) {
        case 0:
            strengthBar.style.width = '0%';
            strengthBar.className = 'strength-bar';
            strengthText.textContent = '';
            break;
        case 1:
            strengthBar.style.width = '25%';
            strengthBar.className = 'strength-bar weak';
            strengthText.textContent = 'Weak';
            break;
        case 2:
            strengthBar.style.width = '50%';
            strengthBar.className = 'strength-bar medium';
            strengthText.textContent = 'Medium';
            break;
        case 3:
            strengthBar.style.width = '75%';
            strengthBar.className = 'strength-bar medium';
            strengthText.textContent = 'Medium';
            break;
        case 4:
            strengthBar.style.width = '100%';
            strengthBar.className = 'strength-bar strong';
            strengthText.textContent = 'Strong';
            break;
    }
});